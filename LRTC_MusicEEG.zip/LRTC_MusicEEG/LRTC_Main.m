clc
clear
close all

%%

load('Subject_8.mat');

%% Isomap: Norm Yaman
Isomap_Norm_Yaman(Subject_8);

%% Isomap: Norm PD
Isomap_Norm_PD(Subject_8);

%% Isomap: Mean Yaman
Isomap_Mean_Yaman(Subject_8);

%% Isomap: Mean PD
Isomap_Mean_PD(Subject_8);

%% PCA: Norm Yaman

PCA_Norm_Yaman(Subject_8);

%% PCA: Norm PD

PCA_Norm_PD(Subject_8);

%% PCA: Mean Yaman
PCA_Mean_Yaman(Subject_8);

%% PCA: Mean PD
PCA_Mean_PD(Subject_8);
